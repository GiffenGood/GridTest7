class e{static register(e,r){var t;null===(t=window.Blazor)||void 0===t||t.registerCustomEventType(e,{createEventArgs:r})}}export{e as C};
