const o="dxbl-popup-root";export{o as d};
