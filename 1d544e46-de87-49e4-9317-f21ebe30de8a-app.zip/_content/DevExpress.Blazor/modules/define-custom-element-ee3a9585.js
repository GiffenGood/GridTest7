const e=document;function t(t,n,o){const c=e.querySelectorAll(n),l=c.length;for(let e=0;e<l;e++)t.upgrade(c[e]);t.define(n,o)}export{t as defineDxCustomElement};
